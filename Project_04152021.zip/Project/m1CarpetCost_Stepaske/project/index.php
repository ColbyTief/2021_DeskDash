<!DOCTYPE html>
<html lang="en">
	       
<head>
	<title>Desk Dash</title>
	<meta charset="utf-8">
		       
	<link href="css/styles.css" rel="stylesheet">

    <?php
    $bg = $_POST['bgColor'];
    $fg = $_POST['fgColor'];
    $font = $_POST['fontChoice'];
    ?>

</head>

<body style=<?php echo "\"background-color: ". $bg ."; color: ". $fg ."; font-family: ". $font .";\""?>>

<?php
    //Define Helper Functions:
    function sanitizeString($field) {
        return filter_input(INPUT_POST, $field, FILTER_SANITIZE_STRING);

    }

    function sanitizeFloat($field){
        return filter_input(INPUT_POST, $field, FILTER_SANITIZE_NUMBER_FLOAT,
    FILTER_FLAG_ALLOW_FRACTION);
    }

    function squareArea($roomLength, $roomWidth){
        return $roomLength * $roomWidth;
    }

    function calculateCost($squareFootage, $selectedCarpets, $prices){
        $grandTotal = 0;

        echo "\t\t<ul>\n";
        //For each carpet choice in $selectedCarpets, we need to determine
        //the cost of carpeting the user's room and display the estimate
        //for each chosen type of carpeting in a bulleted list. 
        foreach ($selectedCarpets as $carpetType) {
            //Determine the cost for this type of carpeting
            $cost = $prices[$carpetType] * $squareFootage;

            //Add this cost to our running grand total (accumulator)
            $grandTotal += $cost;

            //Display info
            echo "\t\t\t<li> At $" . number_format($prices[$carpetType], 2) . " per square foot of $carpetType carpeting, your cost will be $" . number_format($cost, 2) . "</li>\n";

        }

        echo "\t\t</ul>\n";

        //Display grand total
        echo "<br>For a grand total of: $" . number_format($grandTotal, 2) ."\n";
    }

    //Sanitize the form data
    $submitPressed = sanitizeString('submit');
    //echo "<h3>submitPressed contains: $submitPressed</h3>";

    //Determine if the form has been submitted
    if (isset($submitPressed)) { //the form has been submitted
        //
        //Set up an associative array containing the carpet types as its
        //keys (indices) and the price per square foot as its values. 

        //Pass the keys and values of each element
        $carpetPrices = array("Berber" => 5.99, "Shag" => 3.25, "Astroturf" => 9.25, "Plush" => 1.50, 
        "Commercial" => 2.00, "Loop Pile" => 2.50, "Rug" => 4.00);

        //Greet the user
        echo "\n\t\t<h3> Welcome to Billy Bob's Carpet Warehouse ", sanitizeString('fName'), " ", sanitizeString('lName'), "!</h3>";

        //Determine the square footage of the room to be carpeted
        $roomLength = sanitizeFloat('length');
        $roomWidth = sanitizeFloat('width');

        //Calculate room area
        $roomArea = squareArea($roomLength, $roomWidth);

        $footWidthString = "feet";
        $footLengthString = "feet";
        $footAreaString = "feet";

        if ($roomLength == 1) {
            $footLengthString = "foot";
        }

        if ($roomWidth == 1) {
            $footWidthString = "foot";
        }

        if ($roomArea == 1) {
            $footAreaString = "foot";
        }

        echo "\t\tFor a room of $roomLength $footLengthString by $roomWidth $footWidthString, we have a square footage value of $roomArea $footAreaString<br><br>\n";

        //Determine the cost of carpeting the users room for each chosen
        //type of carpeting. Display the info for each chosen type in
        //bulleted list. 
        calculateCost($roomArea, $_POST['restaurantChoice'], $carpetPrices);

    }


        
    ?> 
        

</body>

</html>